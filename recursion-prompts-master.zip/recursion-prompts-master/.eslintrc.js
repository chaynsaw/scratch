module.exports = {
  "extends": "airbnb",
  "installedESLint": true
};
